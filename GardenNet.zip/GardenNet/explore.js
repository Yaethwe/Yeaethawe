const viewport = document.getElementById("viewportDiv");
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBaPvnzqor_4HfPZg6ayk30Tb1RpcMBWfo",
    authDomain: "test-66b58.firebaseapp.com",
    projectId: "test-66b58",
    storageBucket: "test-66b58.appspot.com",
    messagingSenderId: "39985206495",
    appId: "1:39985206495:web:c4200c42a6e7bad4da456a",
    measurementId: "G-G1RBDR6H1S"
};
firebase.initializeApp(firebaseConfig);
const dbRef = firebase.database().ref();
let url = location.href;
let paramaters = (new URL(url)).searchParams;
let link = paramaters.get("url");
let postItems = `
<center>
<div>
	<h1>Currently not avaliable.</h1>
</div>
</center>
`;


viewport.innerHTML=postItems;