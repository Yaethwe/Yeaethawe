
class Shop {
    constructor(name, type, money, items, followers){
        this.name=name;
        this.type=type;
        this.money=money;
        this.items=items;
        this.followers=followers;
    }
    get(x){
        switch(x){
            case "list":
                const list =[
                    this.name,
                    this.type,
                    this.money,
                    this.items,
                    this.followers,
                ]; 
                return list;
                break;
            case "obj":
                const obj ={
                    name:this.name,
                    type:this.type,
                    money:this.money,
                    items:this.items,
                    followers:this.followers
                }
        }
    }
    update(key,value){
        switch(key){
            case "name":
                this.name=value;
                break;
            case "type":
                this.type=value;
                break;
            case "money":
                this.money=value;
                break;
            case "items":
                this.items=value;
                break;
            case "followers":
                this.followers=value;
                break;
            default:
                console.error(`No keys was named ${key}.`)
        } 
    }
}

function getDay(){
switch (new Date().getDay()) {
    case 0:
        return "Sunday";
        break;
    case 1:
        return "Monday";
        break;
    case 2:
        return "Tuesday";
        break;
    case 3:
        return "Wednesday";
        break;
    case 4:
        return "Thursday";
        break;
    case 5:
        return "Friday";
        break;
    case 6:
        return "Saturday";
}
}

const ali = new Shop('ali','mobine store',0,0,0);
console.log(ali.get("obj"));