const creator = document.getElementById("creator"),
    postTitle = document.getElementById("postTitleCT"),
    postBody = document.getElementById("postBodyCT"),
    firebaseConfig = {
        apiKey: "AIzaSyBaPvnzqor_4HfPZg6ayk30Tb1RpcMBWfo",
        authDomain: "test-66b58.firebaseapp.com",
        projectId: "test-66b58",
        storageBucket: "test-66b58.appspot.com",
        messagingSenderId: "39985206495",
        appId: "1:39985206495:web:c4200c42a6e7bad4da456a",
        measurementId: "G-G1RBDR6H1S",
    };
firebase.initializeApp(firebaseConfig);
const dbRef = firebase.database().ref();
let url = location.href,
    paramaters = new URL(url).searchParams,
    gid = paramaters.get("gid"),
    gname = paramaters.get("gname"),
    gtitle = paramaters.get("gtitle");
var mails;
function post() {
    null == gid || null == gname ? alert("Login and try again.") : writePost(gid, gname, postTitle.value, postBody.value);
}
function importDoc() {
    null == gid || null == gname ? alert("Login and try again.") : importDocument(gid, postTitle.value);
}
function writePost(t, e, a, o) {
    firebase
        .database()
        .ref("mails/" + t + "/mails/" + a)
        .set({ body: o, title: a, user: e });
    let i = `explorer.html?gid=${t}&gname=${a}`;
    alert("Your post was successfully created.");
	creator.innerHTML = `
	<a href="https://gardennet.netlify.app/${i}" target="_blank" >Click Here To Go To Your posted page's Link:<br> https://gardennet.netlify.app/${i}</a>
	<button class="nbtn" onclick="location.reload()">Come Back To Post Creator</button>
	`;
}
function importDocument(t, e) {
    dbRef
        .child("mails")
        .child(t)
        .child("mails")
        .child(e)
        .get()
        .then((t) => {
            t.exists() ? ((mails = t.val()), loadData()) : alert("404 not found");
        })
        .catch((t) => {
            console.error(t);
        });
}
function loadData() {
    postBody.textContent = mails.body;
}
gtitle && (postTitle.value = gtitle);
let help =
    "\n\x3c!-- How to import a document --\x3e\nTo import a previous version of your document or project,\nyou need to type it's title correctly in title input box\nthen click import button at the top.\nIf you type your previous document title correctly.\nWoosh! You will see your previous html codes.\n \n\x3c!-- How to use gid, gname & gtitle paramaters --\x3e\nIf you want to make a post manually in create.html\nyou need to fill id at your gid parameter like this '?gid=001' and\nfor gname fill your name like this '?gid=001&gname=YourName'\nIf you want to fill the doc title automitically at there\nfill gtitle parameter as just like this '?gid=001&gname=YourName&gtitle=DocName'\n";
function helpfunc() {
    postBody.textContent = help;
}
