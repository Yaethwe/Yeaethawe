const mailBox = document.getElementById("mailBox");
const pageTitle = document.getElementById("pageTitle");
const e404 = `
	  <div class="mailDiv">
	  <label>Author <span style="color:blue;">REQUEST ERROR</span></label>
		<div class="mailTitle">Error 404</div>
		<div class="mailBody">
		<label>- Page not found.</label><br>
		<label>- <a href="https://gardennet.netlify.app/explorer?gid=2&gname=GardenNetDoc" target="_blank">Click here</a> to read GardenNet Documentetion.</label><br>
		<label>- If you are not connected with internet, connect it and try again.</label><br><hr>
		<button class="nbtn" onclick="location.reload()">Try Again</button>
		</div>
	  </div>
	  `;
var currentUrl = window.location.href;
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBaPvnzqor_4HfPZg6ayk30Tb1RpcMBWfo",
    authDomain: "test-66b58.firebaseapp.com",
    projectId: "test-66b58",
    storageBucket: "test-66b58.appspot.com",
    messagingSenderId: "39985206495",
    appId: "1:39985206495:web:c4200c42a6e7bad4da456a",
    measurementId: "G-G1RBDR6H1S"
};
firebase.initializeApp(firebaseConfig);
const dbRef = firebase.database().ref();
let url = location.href;
let paramaters = (new URL(url)).searchParams;
let gid = paramaters.get("gid");
let gname = paramaters.get("gname");



var mails;
var mail;
var all;
function getData(i,n) {
  dbRef.child("mails").child(i).child("mails").child(n).get().then((snapshot) => {
    if (snapshot.exists()) {
      mails = snapshot.val();
      loadMails();
    } else {
      mailBox.innerHTML=e404;
    }
  }).catch((error) => {
    console.error(error);
  });
}

function loadMails() {
  pageTitle.textContent=`${mails.title} - Explorer GardenNet`;
  mailBox.innerHTML=`
  <div class="mailDiv">
  <label>Author <span style="color:blue;">${mails.user}.</span></label>
  <div class="mailTitle">${mails.title}</div>
  <div class="mailBody">${mails.body}</div>
  </div>
`;

}
setTimeout(1000);
getData(gid,gname);
