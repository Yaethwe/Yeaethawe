const tabtitle = document.getElementById("tabtitle");
const title = document.getElementById("title")

class Shop {
    constructor(name,type,money,items,followers){
        this.name=name;
        this.type=type;
        this.money=money;
        this.items=items;
        this.followers=followers;
    }
    get(){
        const list =[
            this.name,
            this.type,
            this.money,
            this.items,
            this.followers,
        ]; 
        return list;
    }
    update(key,value){
        switch(key){
            case "name":
                this.name=value;
                break;
            case "type":
                this.type=value;
                break;
            case "money":
                this.money=value;
                break;
            case "items":
                this.items=value;
                break;
            case "followers":
                this.followers=value;
                break;
            default:
                console.error(`No keys was named ${key}.`)
        } 
    }
}
let balance = 100;
const quality = new Shop("Quality", "mobile store", balance, 3, 121);
quality.update("y","hook");
console.log(quality.get());

var day;
switch (new Date().getDay()) {
    case 0:
      day = "Sunday";
      break;
    case 1:
      day = "Monday";
      break;
    case 2:
       day = "Tuesday";
      break;
    case 3:
      day = "Wednesday";
      break;
    case 4:
      day = "Thursday";
      break;
    case 5:
      day = "Friday";
      break;
    case 6:
      day = "Saturday";
  }