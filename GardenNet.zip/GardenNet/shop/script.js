const body = document.getElementById("body");

const firebaseConfig = {
    apiKey: "AIzaSyBaPvnzqor_4HfPZg6ayk30Tb1RpcMBWfo",
    authDomain: "test-66b58.firebaseapp.com",
    projectId: "test-66b58",
    storageBucket: "test-66b58.appspot.com",
    messagingSenderId: "39985206495",
    appId: "1:39985206495:web:c4200c42a6e7bad4da456a",
    measurementId: "G-G1RBDR6H1S"
};
firebase.initializeApp(firebaseConfig);
const dbRef = firebase.database().ref();
const shopWeb = dbRef.child('shops');

const url = location.href;
const paramaters = (new URL(url)).searchParams;
const shopName = paramaters.get("s");
const code = shopWeb.child(shopName).get();
let tname = code.name;
let tcreator = code.creator;
let tbody = code.body;

function updateBody(x) {
    body.innerHTML=x;
}

updateBody(tbody);